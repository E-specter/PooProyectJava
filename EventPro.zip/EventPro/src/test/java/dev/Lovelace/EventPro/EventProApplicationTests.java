package dev.Lovelace.EventPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventProApplicationTests {

	@Test
	void contextLoads() {
	}

}
