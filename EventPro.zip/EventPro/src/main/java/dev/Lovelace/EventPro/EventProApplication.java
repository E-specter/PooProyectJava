package dev.Lovelace.EventPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventProApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventProApplication.class, args);
	}

}
